package exammanagementsystem;
import java.io.IOException;
import java.awt.*;
import java.util.*;
import javax.swing.*;

public class ExamManagementSystem {

    public static void main(String[] args) throws IOException  {
        
         School s = new School();
         
         Login l = new Login();
         l.setVisible(true);
    
    }
}