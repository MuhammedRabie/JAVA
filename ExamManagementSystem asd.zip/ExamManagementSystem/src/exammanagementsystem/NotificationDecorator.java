/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exammanagementsystem;

/**
 *
 * @author nour
 */
public class NotificationDecorator implements Notifacation {

    Notifacation notif;

    @Override
    public String SendNotification() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

}
